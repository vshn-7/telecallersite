package com.fl.springjsp.response;

public class CommonLeadResponseDTO extends BaseResponseDTO{
	public String leadId;
	public String custId;
	public String getLeadId() {
		return leadId;
	}
	public void setLeadId(String leadId) {
		this.leadId = leadId;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	@Override
	public String toString() {
		return "CommonLeadResponseDTO [leadId=" + leadId + ", custId=" + custId + "]";
	}
	public CommonLeadResponseDTO() {
		super();
	}
	
	
}
