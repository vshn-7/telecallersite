package com.fl.springjsp.response;

import java.util.List;

public class UnallocatedResponseDTO extends BaseResponseDTO{

	private List<UnallocatedLeads> leadDetails;

	public List<UnallocatedLeads> getLeadDetails() {
		return leadDetails;
	}
	public void setLeadDetails(List<UnallocatedLeads> leadDetails) {
		this.leadDetails = leadDetails;
	}
}
