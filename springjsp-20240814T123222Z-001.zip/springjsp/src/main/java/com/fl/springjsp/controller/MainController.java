package com.fl.springjsp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.fl.springjsp.response.LoginResponseDTO;
import com.fl.springjsp.response.TcAgentResponseDTO;
import com.fl.springjsp.service.LoginService;
import com.fl.springjsp.service.TcService;
import com.fl.springjsp.sessionvariables.SessionVariables;


@Controller
public class MainController {
	@Autowired
	public LoginService loginService;
	

	@RequestMapping("/login")
	public String loginPage() {
		return "login";
	}
	
	@RequestMapping("/logout")
	public String logoutPage() {
		return "login";
	}
	
	@PostMapping("/login")
    public String handleLogin(@RequestParam("username") String username,
                              @RequestParam("password") String password,
                              Model model) {
		
		LoginResponseDTO response  = loginService.handleLogin(username, password);
		if(response.getStatusCode().equals("1")) {
			SessionVariables sessionVariable = SessionVariables.getInstance();
			sessionVariable.setUsername(username);
			if(response.getUserType().equals("TS")) {
				TcAgentResponseDTO tcResponse  = loginService.populateTcDetails();
				sessionVariable.setTcResponse(tcResponse);
				model.addAttribute("response",tcResponse);
				return "tc";
			}
			else {
				return "adminDashboard";
			}
		}
		
		return "login";
    }
	
	@RequestMapping("/adminDashboard")
    public String adminDashboard() {
        return "adminDashboard";
    }
	
	
		
}
