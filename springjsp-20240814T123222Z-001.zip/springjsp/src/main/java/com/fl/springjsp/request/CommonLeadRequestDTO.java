package com.fl.springjsp.request;

public class CommonLeadRequestDTO extends BaseRequestDTO{
	public String leadSource;
	public String leadId;
	public String getLeadSource() {
		return leadSource;
	}
	public void setLeadSource(String leadSource) {
		this.leadSource = leadSource;
	}
	public String getLeadId() {
		return leadId;
	}
	public void setLeadId(String leadId) {
		this.leadId = leadId;
	}
	@Override
	public String toString() {
		return "CommonLeadRequestDTO [leadSource=" + leadSource + ", leadId=" + leadId + "]";
	}
	public CommonLeadRequestDTO() {
		super();
	}
	
	

}
