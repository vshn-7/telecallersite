package com.fl.springjsp.response;

public class OkycOption{
    public String option;
    public String displayString;
}
