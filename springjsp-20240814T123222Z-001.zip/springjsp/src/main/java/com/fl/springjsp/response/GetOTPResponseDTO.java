package com.fl.springjsp.response;

public class GetOTPResponseDTO {
	private String statusCode;
	private String statusMessage;
	private String random;
	private String leadId;
	private String otp;
	
	public GetOTPResponseDTO() {
		super();
	}
	public GetOTPResponseDTO(String statusCode, String statusMessage, String random, String leadId, String otp) {
		super();
		this.statusCode = statusCode;
		this.statusMessage = statusMessage;
		this.random = random;
		this.leadId = leadId;
		this.otp = otp;
	}
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	public String getRandom() {
		return random;
	}
	public void setRandom(String random) {
		this.random = random;
	}
	public String getLeadId() {
		return leadId;
	}
	public void setLeadId(String leadId) {
		this.leadId = leadId;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	@Override
	public String toString() {
		return "GetOTPResponseDTO [statusCode=" + statusCode + ", statusMessage=" + statusMessage + ", random=" + random
				+ ", leadId=" + leadId + ", otp=" + otp + "]";
	}
	
	
}
