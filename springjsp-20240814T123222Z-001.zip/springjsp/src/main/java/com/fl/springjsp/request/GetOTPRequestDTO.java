package com.fl.springjsp.request;


public class GetOTPRequestDTO {
	private String name;
	private String phoneNo;
	private String businessName;
	private String leadSource;
	private String appName;
	private String version;
	private String agentId;
	private String leadId;
	
	public GetOTPRequestDTO() {
		super();
	}
	public GetOTPRequestDTO(String name, String phoneNo, String leadId, String businessName, String leadSource,
			String appName, String version, String agentId) {
		super();
		this.name = name;
		this.phoneNo = phoneNo;
		this.leadId = leadId;
		this.businessName = businessName;
		this.leadSource = leadSource;
		this.appName = appName;
		this.version = version;
		this.agentId = agentId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getLeadId() {
		return leadId;
	}
	public void setLeadId(String leadId) {
		this.leadId = leadId;
	}
	public String getBusinessName() {
		return businessName;
	}
	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}
	public String getLeadSource() {
		return leadSource;
	}
	public void setLeadSource(String leadSource) {
		this.leadSource = leadSource;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getAgentId() {
		return agentId;
	}
	public void setAgentId(String agentId) {
		this.agentId = agentId;
	}
	@Override
	public String toString() {
		return "GetOTPRequestDTO [name=" + name + ", phoneNo=" + phoneNo + ", leadId=" + leadId + ", businessName="
				+ businessName + ", leadSource=" + leadSource + ", appName=" + appName + ", version=" + version
				+ ", agentId=" + agentId + "]";
	}
	
	
	
}
