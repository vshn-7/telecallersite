package com.fl.springjsp.request;

public class LeadRequestDTO extends BaseRequestDTO{
	
    private String type;
	
	public LeadRequestDTO() {
		super();
	}

	

	public LeadRequestDTO(String appName, String version) {
		// TODO Auto-generated constructor stub
		this.appName = appName;
		this.version = version;
	}



	public String getType() {
		return type;
		
	}
	public void setType(String type) {
		this.type = type;
	}
    

}