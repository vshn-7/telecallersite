package com.fl.springjsp.response;

public class StatementOption{
    public String option;
    public String displayString;
}
