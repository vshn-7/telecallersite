package com.fl.springjsp.response;

import java.util.ArrayList;

public class MetaResponseDTO extends BaseResponseDTO{

    public ArrayList<String> jobCategories;
    public ArrayList<String> jobDetails;
    public ArrayList<String> bankNames;
    public ArrayList<String> whatBusiness;
    public ArrayList<String> personalAssets;
    public ArrayList<String> businessAssets;
    public ArrayList<String> houseType;
    public ArrayList<String> otherIncomeType;
    public ArrayList<String> purposeOfLoan;
    public ArrayList<String> paymentMethods;
    public ArrayList<String> upiDebitScheduledTime;
    public ArrayList<MandateOption> mandateOptions;
    public ArrayList<StatementOption> statementOptions;
    public ArrayList<OkycOption> okycOptions;
    public UpiStmnt upiStmnt;
    public ArrayList<String> remarks;
    public ArrayList<String> disposition;
    public ArrayList<String> addressType;
    public ArrayList<String> remarksType;
    public ArrayList<String> remarksDesc;
    public int videoDuration;
    public int minAge;
    public int maxAge;
    public ArrayList<String> hibernateReason;
    public ArrayList<String> relationship;
    public ArrayList<String> leadSource;

	public ArrayList<String> getJobCategories() {
		return jobCategories;
	}
	public void setJobCategories(ArrayList<String> jobCategories) {
		this.jobCategories = jobCategories;
	}
	public ArrayList<String> getJobDetails() {
		return jobDetails;
	}
	public void setJobDetails(ArrayList<String> jobDetails) {
		this.jobDetails = jobDetails;
	}
	public ArrayList<String> getBankNames() {
		return bankNames;
	}
	public void setBankNames(ArrayList<String> bankNames) {
		this.bankNames = bankNames;
	}
	public ArrayList<String> getWhatBusiness() {
		return whatBusiness;
	}
	public void setWhatBusiness(ArrayList<String> whatBusiness) {
		this.whatBusiness = whatBusiness;
	}
	public ArrayList<String> getPersonalAssets() {
		return personalAssets;
	}
	public void setPersonalAssets(ArrayList<String> personalAssets) {
		this.personalAssets = personalAssets;
	}
	public ArrayList<String> getBusinessAssets() {
		return businessAssets;
	}
	public void setBusinessAssets(ArrayList<String> businessAssets) {
		this.businessAssets = businessAssets;
	}
	public ArrayList<String> getHouseType() {
		return houseType;
	}
	public void setHouseType(ArrayList<String> houseType) {
		this.houseType = houseType;
	}
	public ArrayList<String> getOtherIncomeType() {
		return otherIncomeType;
	}
	public void setOtherIncomeType(ArrayList<String> otherIncomeType) {
		this.otherIncomeType = otherIncomeType;
	}
	public ArrayList<String> getPurposeOfLoan() {
		return purposeOfLoan;
	}
	public void setPurposeOfLoan(ArrayList<String> purposeOfLoan) {
		this.purposeOfLoan = purposeOfLoan;
	}
	public ArrayList<String> getPaymentMethods() {
		return paymentMethods;
	}
	public void setPaymentMethods(ArrayList<String> paymentMethods) {
		this.paymentMethods = paymentMethods;
	}
	public ArrayList<String> getUpiDebitScheduledTime() {
		return upiDebitScheduledTime;
	}
	public void setUpiDebitScheduledTime(ArrayList<String> upiDebitScheduledTime) {
		this.upiDebitScheduledTime = upiDebitScheduledTime;
	}
	public ArrayList<MandateOption> getMandateOptions() {
		return mandateOptions;
	}
	public void setMandateOptions(ArrayList<MandateOption> mandateOptions) {
		this.mandateOptions = mandateOptions;
	}
	public ArrayList<StatementOption> getStatementOptions() {
		return statementOptions;
	}
	public void setStatementOptions(ArrayList<StatementOption> statementOptions) {
		this.statementOptions = statementOptions;
	}
	public ArrayList<OkycOption> getOkycOptions() {
		return okycOptions;
	}
	public void setOkycOptions(ArrayList<OkycOption> okycOptions) {
		this.okycOptions = okycOptions;
	}
	public UpiStmnt getUpiStmnt() {
		return upiStmnt;
	}
	public void setUpiStmnt(UpiStmnt upiStmnt) {
		this.upiStmnt = upiStmnt;
	}
	public ArrayList<String> getRemarks() {
		return remarks;
	}
	public void setRemarks(ArrayList<String> remarks) {
		this.remarks = remarks;
	}
	public ArrayList<String> getDisposition() {
		return disposition;
	}
	public void setDisposition(ArrayList<String> disposition) {
		this.disposition = disposition;
	}
	public ArrayList<String> getAddressType() {
		return addressType;
	}
	public void setAddressType(ArrayList<String> addressType) {
		this.addressType = addressType;
	}
	public ArrayList<String> getRemarksType() {
		return remarksType;
	}
	public void setRemarksType(ArrayList<String> remarksType) {
		this.remarksType = remarksType;
	}
	public ArrayList<String> getRemarksDesc() {
		return remarksDesc;
	}
	public void setRemarksDesc(ArrayList<String> remarksDesc) {
		this.remarksDesc = remarksDesc;
	}
	public int getVideoDuration() {
		return videoDuration;
	}
	public void setVideoDuration(int videoDuration) {
		this.videoDuration = videoDuration;
	}
	public int getMinAge() {
		return minAge;
	}
	public void setMinAge(int minAge) {
		this.minAge = minAge;
	}
	public int getMaxAge() {
		return maxAge;
	}
	public void setMaxAge(int maxAge) {
		this.maxAge = maxAge;
	}
	public ArrayList<String> getHibernateReason() {
		return hibernateReason;
	}
	public void setHibernateReason(ArrayList<String> hibernateReason) {
		this.hibernateReason = hibernateReason;
	}
	public ArrayList<String> getRelationship() {
		return relationship;
	}
	public void setRelationship(ArrayList<String> relationship) {
		this.relationship = relationship;
	}
	public ArrayList<String> getLeadSource() {
		return leadSource;
	}
	public void setLeadSource(ArrayList<String> leadSource) {
		this.leadSource = leadSource;
	}
	@Override
	public String toString() {
		return "MetaResponseDTO [statusCode=" + statusCode + ", statusMessage=" + statusMessage + ", random=" + random
				+ ", jobCategories=" + jobCategories + ", jobDetails=" + jobDetails + ", bankNames=" + bankNames
				+ ", whatBusiness=" + whatBusiness + ", personalAssets=" + personalAssets + ", businessAssets="
				+ businessAssets + ", houseType=" + houseType + ", otherIncomeType=" + otherIncomeType
				+ ", purposeOfLoan=" + purposeOfLoan + ", paymentMethods=" + paymentMethods + ", upiDebitScheduledTime="
				+ upiDebitScheduledTime + ", mandateOptions=" + mandateOptions + ", statementOptions="
				+ statementOptions + ", okycOptions=" + okycOptions + ", upiStmnt=" + upiStmnt + ", remarks=" + remarks
				+ ", disposition=" + disposition + ", addressType=" + addressType + ", remarksType=" + remarksType
				+ ", remarksDesc=" + remarksDesc + ", videoDuration=" + videoDuration + ", minAge=" + minAge
				+ ", maxAge=" + maxAge + ", hibernateReason=" + hibernateReason + ", relationship=" + relationship
				+ ", leadSource=" + leadSource + "]";
	}
	public MetaResponseDTO(String statusCode, String statusMessage, Object random, ArrayList<String> jobCategories,
			ArrayList<String> jobDetails, ArrayList<String> bankNames, ArrayList<String> whatBusiness,
			ArrayList<String> personalAssets, ArrayList<String> businessAssets, ArrayList<String> houseType,
			ArrayList<String> otherIncomeType, ArrayList<String> purposeOfLoan, ArrayList<String> paymentMethods,
			ArrayList<String> upiDebitScheduledTime, ArrayList<MandateOption> mandateOptions,
			ArrayList<StatementOption> statementOptions, ArrayList<OkycOption> okycOptions, UpiStmnt upiStmnt,
			ArrayList<String> remarks, ArrayList<String> disposition, ArrayList<String> addressType,
			ArrayList<String> remarksType, ArrayList<String> remarksDesc, int videoDuration, int minAge, int maxAge,
			ArrayList<String> hibernateReason, ArrayList<String> relationship, ArrayList<String> leadSource) {
		super();
		this.statusCode = statusCode;
		this.statusMessage = statusMessage;
		this.random = random;
		this.jobCategories = jobCategories;
		this.jobDetails = jobDetails;
		this.bankNames = bankNames;
		this.whatBusiness = whatBusiness;
		this.personalAssets = personalAssets;
		this.businessAssets = businessAssets;
		this.houseType = houseType;
		this.otherIncomeType = otherIncomeType;
		this.purposeOfLoan = purposeOfLoan;
		this.paymentMethods = paymentMethods;
		this.upiDebitScheduledTime = upiDebitScheduledTime;
		this.mandateOptions = mandateOptions;
		this.statementOptions = statementOptions;
		this.okycOptions = okycOptions;
		this.upiStmnt = upiStmnt;
		this.remarks = remarks;
		this.disposition = disposition;
		this.addressType = addressType;
		this.remarksType = remarksType;
		this.remarksDesc = remarksDesc;
		this.videoDuration = videoDuration;
		this.minAge = minAge;
		this.maxAge = maxAge;
		this.hibernateReason = hibernateReason;
		this.relationship = relationship;
		this.leadSource = leadSource;
	}
	public MetaResponseDTO() {
		// TODO Auto-generated constructor stub
	}
    
    
}
