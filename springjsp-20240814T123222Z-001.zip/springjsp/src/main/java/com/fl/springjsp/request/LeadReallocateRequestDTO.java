package com.fl.springjsp.request;

public class LeadReallocateRequestDTO{
	public String leadId;
	public String appName;
	public String version;
	public String tcAgentCode;
	public String getLeadId() {
		return leadId;
	}
	public void setLeadId(String leadId) {
		this.leadId = leadId;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getTcAgentCode() {
		return tcAgentCode;
	}
	public void setTcAgentCode(String tcAgentCode) {
		this.tcAgentCode = tcAgentCode;
	}
	public LeadReallocateRequestDTO() {
		super();
	}
	
	

}
