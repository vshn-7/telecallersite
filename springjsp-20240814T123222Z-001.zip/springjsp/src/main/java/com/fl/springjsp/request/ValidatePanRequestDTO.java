package com.fl.springjsp.request;

public class ValidatePanRequestDTO {
	private String pan;
	private String leadId;
	private String appName;
	private String version;
	
	public String getPan() {
		return pan;
	}
	public void setPan(String pan_no) {
		this.pan = pan_no;
	}
	public String getLeadId() {
		return leadId;
	}
	public void setLeadId(String leadId) {
		this.leadId = leadId;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	
	@Override
	public String toString() {
		return "VerifyPanRequestDTO [pan_no=" + pan + ", leadId=" + leadId + ", appName=" + appName + ", version="+ version + "]";
	}

}
