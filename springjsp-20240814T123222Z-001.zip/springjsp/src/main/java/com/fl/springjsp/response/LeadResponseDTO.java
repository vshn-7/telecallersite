package com.fl.springjsp.response;

import java.util.List;

public class LeadResponseDTO extends BaseResponseDTO{

    private List<LeadDetails> leadDetails;

    public List<LeadDetails> getLeadDetails() {
        return leadDetails;
    }

    public void setLeadDetails(List<LeadDetails> leadDetails) {
        this.leadDetails = leadDetails;
    }
    
    private String statusCode;
    private String statusMessage;
    private String random;

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }

    public String getRandom() {
        return random;
    }

    public void setRandom(String random) {
        this.random = random;
    }
    
           

    
    
    
    
}