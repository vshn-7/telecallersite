package com.fl.springjsp.response;

public class Individual{
    public String gpay;
    public String phonepe;
    public String paytm;
    public String bharatpe;
}
