package com.fl.springjsp.request;

public class BaseRequestDTO {
	String appName;
	String version;
	String agentCode;
	
	public BaseRequestDTO() {
		
	}
	
	public BaseRequestDTO(String appName, String version) {
		super();
		this.appName = appName;
		this.version = version;
	}

	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getAgentCode() {
		return agentCode;
	}
	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}
	
	@Override
	public String toString() {
		return "BaseRequestDTO {appName=" + appName + ", version=" + version + ", agentCode=" + agentCode + "}";
	}

	
}
