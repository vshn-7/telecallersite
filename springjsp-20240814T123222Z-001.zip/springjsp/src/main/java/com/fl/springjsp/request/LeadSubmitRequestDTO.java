package com.fl.springjsp.request;

public class LeadSubmitRequestDTO {
	private String leadId;
	private String businessPincode;
	private String businessType;
	private String loanPurpose;
	private String dailyUpi;
	private String dailyCash;
	private String workingDays;
	private String maritalStatus;
	private String businessAddress;
	private String custId;
	private String appName;
	private String version;
	private String customerId;
	public String getLeadId() {
		return leadId;
	}
	public void setLeadId(String leadId) {
		this.leadId = leadId;
	}
	public String getBusinessPincode() {
		return businessPincode;
	}
	public void setBusinessPincode(String businessPincode) {
		this.businessPincode = businessPincode;
	}
	public String getBusinessType() {
		return businessType;
	}
	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}
	public String getLoanPurpose() {
		return loanPurpose;
	}
	public void setLoanPurpose(String loanPurpose) {
		this.loanPurpose = loanPurpose;
	}
	public String getDailyUpi() {
		return dailyUpi;
	}
	public void setDailyUpi(String dailyUpi) {
		this.dailyUpi = dailyUpi;
	}
	public String getDailyCash() {
		return dailyCash;
	}
	public void setDailyCash(String dailyCash) {
		this.dailyCash = dailyCash;
	}
	public String getWorkingDays() {
		return workingDays;
	}
	public void setWorkingDays(String workingDays) {
		this.workingDays = workingDays;
	}
	public String getMaritalStatus() {
		return maritalStatus;
	}
	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}
	public String getBusinessAddress() {
		return businessAddress;
	}
	public void setBusinessAddress(String businessAddress) {
		this.businessAddress = businessAddress;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	@Override
	public String toString() {
		return "LeadSubmitRequestDTO [leadId=" + leadId + ", businessPincode=" + businessPincode + ", businessType="
				+ businessType + ", loanPurpose=" + loanPurpose + ", dailyUpi=" + dailyUpi + ", dailyCash=" + dailyCash
				+ ", workingDays=" + workingDays + ", maritalStatus=" + maritalStatus + ", businessAddress="
				+ businessAddress + ", custId=" + custId + ", appName=" + appName + ", version=" + version
				+ ", customerId=" + customerId + ", toString()=" + super.toString() + "]";
	}
	
}
