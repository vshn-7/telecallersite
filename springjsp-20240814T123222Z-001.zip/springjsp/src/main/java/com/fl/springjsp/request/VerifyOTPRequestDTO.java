package com.fl.springjsp.request;

public class VerifyOTPRequestDTO {
	private String otp;
	private String name;
	private String leadId;
	private String appName;
	private String version;
	
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLeadId() {
		return leadId;
	}
	public void setLeadId(String leadId) {
		this.leadId = leadId;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	
	
	@Override
	public String toString() {
		return "VerifyOTPRequestDTO [otp=" + otp + ", name=" + name + ", leadId=" + leadId + ", appName=" + appName
				+ ", version=" + version + "]";
	}
	

}
