package com.fl.springjsp.response;

public class UpiStmnt{
    public Merchant merchant;
    public Individual individual;
}
