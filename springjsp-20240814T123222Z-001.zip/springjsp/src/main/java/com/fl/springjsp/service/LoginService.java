package com.fl.springjsp.service;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.fl.springjsp.request.LeadRequestDTO;
import com.fl.springjsp.request.LoginRequestDTO;
import com.fl.springjsp.request.BaseRequestDTO;

import com.fl.springjsp.response.BaseResponseDTO;
import com.fl.springjsp.response.LoginResponseDTO;
import com.fl.springjsp.response.TcAgentResponseDTO;
import com.fl.springjsp.sessionvariables.SessionVariables;
import com.fl.springjsp.sessionvariables.Utils;

@Service
public class LoginService {
	public static SessionVariables sessionInstance = SessionVariables.getInstance();
	public static RestTemplate restTemplate = new RestTemplate();
	public LoginResponseDTO handleLogin(String username,String password) {
		
        String url = Utils.url+"tcLogin"; 
        LoginRequestDTO loginRequest = new LoginRequestDTO();
        loginRequest.setUsername(username);
        loginRequest.setPassword(password);

        LoginResponseDTO response  = restTemplate.postForObject(url, loginRequest, LoginResponseDTO.class);
        return response;
		
			
	}
	
	public TcAgentResponseDTO populateTcDetails() {
		String url = Utils.url+"getTCagentDashboard"; 
        BaseRequestDTO request = new BaseRequestDTO();
        request.setAgentCode(sessionInstance.getUsername());
        request.setAppName(Utils.appName);
        request.setVersion(Utils.version);
        
        TcAgentResponseDTO response  = restTemplate.postForObject(url, request, TcAgentResponseDTO.class);
        return response;
	}
}
