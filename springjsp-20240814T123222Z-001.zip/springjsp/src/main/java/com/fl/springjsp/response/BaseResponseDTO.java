package com.fl.springjsp.response;

public class BaseResponseDTO {
    public String statusCode;
    public String statusMessage;
    public Object random;
	public String getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusMessage() {
		return statusMessage;
	}
	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}
	public Object getRandom() {
		return random;
	}
	public void setRandom(Object random) {
		this.random = random;
	}
	public BaseResponseDTO() {
		super();
	}
	
	@Override
	public String toString() {
		return "BaseResponseDTO [statusCode=" + statusCode + ", statusMessage=" + statusMessage + ", random=" + random
				+ ", toString()=" + super.toString() + "]";
	}
	
    
}
