package com.fl.springjsp.response;

public class LoginResponseDTO extends BaseResponseDTO{
	private String userLevel;
	private String userType;
	
	public LoginResponseDTO() {
		super();
	}
	public String getUserLevel() {
		return userLevel;
	}
	public void setUserLevel(String userLevel) {
		this.userLevel = userLevel;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	
	
}
