package com.fl.springjsp.response;

public class ReworkLeadDetails{
	
    public String leadId;
    public String custId;
    public String agentCode;
    public String name;
    public String businessName;
    public String phoneNo;
    public String bunessAddress;
    public String pan;
    public Object tcAgentCode;
    public String provisionalOffer;
    public String status;
    public String createTime;
    public String reworkStatus;
    public String reworkReason;
    public String rescheduleDate;
	public String getLeadId() {
		return leadId;
	}
	public void setLeadId(String leadId) {
		this.leadId = leadId;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getAgentCode() {
		return agentCode;
	}
	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBusinessName() {
		return businessName;
	}
	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getBunessAddress() {
		return bunessAddress;
	}
	public void setBunessAddress(String bunessAddress) {
		this.bunessAddress = bunessAddress;
	}
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public Object getTcAgentCode() {
		return tcAgentCode;
	}
	public void setTcAgentCode(Object tcAgentCode) {
		this.tcAgentCode = tcAgentCode;
	}
	public String getProvisionalOffer() {
		return provisionalOffer;
	}
	public void setProvisionalOffer(String provisionalOffer) {
		this.provisionalOffer = provisionalOffer;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	public String getReworkStatus() {
		return reworkStatus;
	}
	public void setReworkStatus(String reworkStatus) {
		this.reworkStatus = reworkStatus;
	}
	public String getReworkReason() {
		return reworkReason;
	}
	public void setReworkReason(String reworkReason) {
		this.reworkReason = reworkReason;
	}
	public String getRescheduleDate() {
		return rescheduleDate;
	}
	public void setRescheduleDate(String rescheduleDate) {
		this.rescheduleDate = rescheduleDate;
	}
    
}
