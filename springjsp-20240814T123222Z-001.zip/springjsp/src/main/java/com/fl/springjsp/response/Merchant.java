package com.fl.springjsp.response;

public class Merchant{
    public String gpay;
    public String phonepe;
    public String paytm;
    public String bharatpe;
}
