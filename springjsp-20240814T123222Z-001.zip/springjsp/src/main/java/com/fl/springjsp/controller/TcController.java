package com.fl.springjsp.controller;

import java.util.ArrayList;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fl.springjsp.request.BaseRequestDTO;
import com.fl.springjsp.request.LeadRequestDTO;
import com.fl.springjsp.response.CommonLeadResponseDTO;
import com.fl.springjsp.response.LeadResponseDTO;
import com.fl.springjsp.response.MetaResponseDTO;
import com.fl.springjsp.response.TcAgentResponseDTO;
import com.fl.springjsp.service.TcService;
import com.fl.springjsp.sessionvariables.SessionVariables;

import jakarta.servlet.http.HttpSession;

import org.springframework.ui.Model;
@Controller
public class TcController {
	@Autowired
	public TcService tcService;
	private MetaResponseDTO response = new MetaResponseDTO();
	 
	@RequestMapping("/addLead1")
	public String addLead1(Model model) {
		response = tcService.dropdowns();
		model.addAttribute("response", response);
		return "addLead1";
	}

	@RequestMapping("/generateOTP")
	@ResponseBody
    public void generateOTP(@RequestParam("name") String name,
                            @RequestParam("phone_no") String phoneNo,
                            @RequestParam("business_name") String businessName,
                            @RequestParam("business_type") String businessType,
                            HttpSession session) {
        // Save details in session
        session.setAttribute("name", name);
        session.setAttribute("phone_no", phoneNo);
        session.setAttribute("business_name", businessName);
        session.setAttribute("business_type", businessType);
        
        String otp = tcService.generateRandomOTP(name,phoneNo,businessName,businessType);
    }

    @RequestMapping("/validateOTP")
    public String validateOTP(@RequestParam("otp") String userOtp, HttpSession session, Model model) {
    	if(tcService.verifyOTP(userOtp,session)) {
    		return addLead3(model);
    	}
    	else {
    		return addLead1(model);
    	}
    }
	
	@RequestMapping("/addLead3")
	public String addLead3(Model model) {
		model.addAttribute("response", response);
		return "addLead3";
	}
	
	@RequestMapping("/verifyPAN")
    @ResponseBody
    public Map<String, String> verifyPan(@RequestParam("Pan_No") String Pan_No, HttpSession session) {
		
		session.setAttribute("pan_No", Pan_No);
		
		Map<String, String> panDetails = tcService.verifyPAN(Pan_No,session);
		
        return panDetails;
    }

	@RequestMapping("/addLead5")
	public String addLead5(Model model, HttpSession session) {
		
		String custId = tcService.dedupeLead();
		
		if(custId!=null && !custId.equals("") ) {
			model.addAttribute("response", response);
			model.addAttribute("name", session.getAttribute("name"));
			model.addAttribute("business_name", (String) session.getAttribute("business_name"));
			model.addAttribute("phone_no", (String) session.getAttribute("phone_no"));
			model.addAttribute("pan_no", (String) session.getAttribute("pan_No"));
			model.addAttribute("business_type", (String) session.getAttribute("business_type"));
			model.addAttribute("cust_id",custId);
			return "addLead5";
		}
		
		return "addLead3";
		
	}
	
	@RequestMapping("/leadSubmit")
    public String leadSubmit(@RequestParam("business_pincode") String businessPincode,
                            @RequestParam("business_type") String businessType,
                            @RequestParam("loan_purpose") String loanPurpose,
                            @RequestParam("daily_upi") String dailyUpi,
                            @RequestParam("daily_cash") String dailyCash,
                            @RequestParam("working_days_per_week") String workingDays,
                            @RequestParam("marital_status") String maritalStatus,
                            @RequestParam("business_address") String businessAddress,
                            @RequestParam("cust_id") String custId,
                            HttpSession session,Model model) {
		
		System.out.println("leadSubmit Controller RequestData------------> " + businessPincode+ businessType+loanPurpose+dailyUpi);
        tcService.leadSubmit(businessPincode,businessType,loanPurpose,dailyUpi,dailyCash,workingDays,maritalStatus,businessAddress,custId);
        SessionVariables sessionVariable = SessionVariables.getInstance();
        System.out.println("leadSubmit Controller Session Data------------> " + sessionVariable.getTcResponse());
		model.addAttribute("response",sessionVariable.getTcResponse());
        return "tc";
    }
	
	@RequestMapping("/tcDashboard")
	public String tcDashboard(Model model) {
		SessionVariables sessionVariable = SessionVariables.getInstance();
		model.addAttribute("response",sessionVariable.getTcResponse());
		return "tc";
	}

    @RequestMapping("/myLeads")
    public String showLeads(Model model) {

        LeadResponseDTO response = tcService.callMyLeadApi();

        if (response != null && response.getStatusCode() != "0") {
            model.addAttribute("response", response);
            model.addAttribute("username", "Deepak");
            return "myLeads";

        }

        model.addAttribute("errorMessage", "Failed to fetch leads or no leads available.");
        return "error";

    }


}
