package com.fl.springjsp.response;

import java.util.ArrayList;

public class TcAgentListResponseDTO extends BaseResponseDTO{
	public ArrayList<String> tcAgentList;

	public ArrayList<String> getTcAgentList() {
		return tcAgentList;
	}

	public void setTcAgentList(ArrayList<String> tcAgentList) {
		this.tcAgentList = tcAgentList;
	}

}
