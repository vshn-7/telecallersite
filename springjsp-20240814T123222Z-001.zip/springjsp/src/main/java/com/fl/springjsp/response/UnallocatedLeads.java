package com.fl.springjsp.response;

public class UnallocatedLeads {
		private String leadId;
		private String custId;
		private String agentCode;
		private String name;
		private String businessName;
		private String pan;
		private String tcAgentCode;
		private String provisionalOffer;
		private String status;
		private String createTime;
		private String reworkStatus;
		private String reworkReason;
		private String rescheduleDate;
		public String getLeadId() {
			return leadId;
		}
		public void setLeadId(String leadId) {
			this.leadId = leadId;
		}
		public String getCustId() {
			return custId;
		}
		public void setCustId(String custId) {
			this.custId = custId;
		}
		public String getAgentCode() {
			return agentCode;
		}
		public void setAgentCode(String agentCode) {
			this.agentCode = agentCode;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getBusinessName() {
			return businessName;
		}
		public void setBusinessName(String businessName) {
			this.businessName = businessName;
		}
		public String getPan() {
			return pan;
		}
		public void setPan(String pan) {
			this.pan = pan;
		}
		public String getTcAgentCode() {
			return tcAgentCode;
		}
		public void setTcAgentCode(String tcAgentCode) {
			this.tcAgentCode = tcAgentCode;
		}
		public String getProvisionalOffer() {
			return provisionalOffer;
		}
		public void setProvisionalOffer(String provisionalOffer) {
			this.provisionalOffer = provisionalOffer;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public String getCreateTime() {
			return createTime;
		}
		public void setCreateTime(String createTime) {
			this.createTime = createTime;
		}
		public String getReworkStatus() {
			return reworkStatus;
		}
		public void setReworkStatus(String reworkStatus) {
			this.reworkStatus = reworkStatus;
		}
		public String getReworkReason() {
			return reworkReason;
		}
		public void setReworkReason(String reworkReason) {
			this.reworkReason = reworkReason;
		}
		public String getRescheduleDate() {
			return rescheduleDate;
		}
		public void setRescheduleDate(String rescheduleDate) {
			this.rescheduleDate = rescheduleDate;
		}
	  
}
