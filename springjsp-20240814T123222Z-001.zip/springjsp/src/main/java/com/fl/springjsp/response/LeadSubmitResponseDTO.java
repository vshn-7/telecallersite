package com.fl.springjsp.response;

public class LeadSubmitResponseDTO {
	private String approved;
	private String provisionalStatus;
	private String crifScore;
	private String greetingText;
	private String defaultLoanOffer;
	
	public String getApproved() {
		return approved;
	}
	public void setApproved(String approved) {
		this.approved = approved;
	}
	public String getProvisionalStatus() {
		return provisionalStatus;
	}
	public void setProvisionalStatus(String provisionalStatus) {
		this.provisionalStatus = provisionalStatus;
	}
	public String getCrifScore() {
		return crifScore;
	}
	public void setCrifScore(String crifScore) {
		this.crifScore = crifScore;
	}
	public String getGreetingText() {
		return greetingText;
	}
	public void setGreetingText(String greetingText) {
		this.greetingText = greetingText;
	}
	public String getDefaultLoanOffer() {
		return defaultLoanOffer;
	}
	public void setDefaultLoanOffer(String defaultLoanOffer) {
		this.defaultLoanOffer = defaultLoanOffer;
	}
	@Override
	public String toString() {
		return "LeadSubmitResponseDTO [approved=" + approved + ", provisionalStatus=" + provisionalStatus
				+ ", crifScore=" + crifScore + ", greetingText=" + greetingText + ", defaultLoanOffer="
				+ defaultLoanOffer + ", toString()=" + super.toString() + "]";
	}

}
