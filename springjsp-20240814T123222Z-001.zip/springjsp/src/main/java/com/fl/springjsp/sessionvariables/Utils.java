package com.fl.springjsp.sessionvariables;

public class Utils {
	
	public static String url = "http://35.154.34.229:8080/FLUPLIFT/";
	public static String appName = "in.fl.uplift.agent";
	public static String version = "87.00";

	
	public Utils() {
		super();
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	
}
