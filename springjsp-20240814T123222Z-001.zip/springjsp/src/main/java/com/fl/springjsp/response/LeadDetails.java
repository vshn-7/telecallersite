package com.fl.springjsp.response;

public class LeadDetails {
	  
    private String id;
    private String custId;
    private String agentCode;
    private String name;
    private String businessName;
    private String businessType;
    private String businessAddress;
    private String businessPincode;
    private String phoneno;
    private String userPan;
    private String panFullName;
    private String reworkStatus;
    private String status;
    private String otpStatus;
    private String panStatus;
    private String provisionOffer;
    private String leadSource;
    private String reworkReason;
    private String rescheduleDate;
    private String taskCreated;
    private String dedupeStatus;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getAgentCode() {
		return agentCode;
	}
	public void setAgentCode(String agentCode) {
		this.agentCode = agentCode;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBusinessName() {
		return businessName;
	}
	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}
	public String getBusinessType() {
		return businessType;
	}
	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}
	public String getBusinessAddress() {
		return businessAddress;
	}
	public void setBusinessAddress(String businessAddress) {
		this.businessAddress = businessAddress;
	}
	public String getBusinessPincode() {
		return businessPincode;
	}
	public void setBusinessPincode(String businessPincode) {
		this.businessPincode = businessPincode;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	public String getUserPan() {
		return userPan;
	}
	public void setUserPan(String userPan) {
		this.userPan = userPan;
	}
	public String getPanFullName() {
		return panFullName;
	}
	public void setPanFullName(String panFullName) {
		this.panFullName = panFullName;
	}
	public String getReworkStatus() {
		return reworkStatus;
	}
	public void setReworkStatus(String reworkStatus) {
		this.reworkStatus = reworkStatus;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getOtpStatus() {
		return otpStatus;
	}
	public void setOtpStatus(String otpStatus) {
		this.otpStatus = otpStatus;
	}
	public String getPanStatus() {
		return panStatus;
	}
	public void setPanStatus(String panStatus) {
		this.panStatus = panStatus;
	}
	public String getProvisionOffer() {
		return provisionOffer;
	}
	public void setProvisionOffer(String provisionOffer) {
		this.provisionOffer = provisionOffer;
	}
	public String getLeadSource() {
		return leadSource;
	}
	public void setLeadSource(String leadSource) {
		this.leadSource = leadSource;
	}
	public String getReworkReason() {
		return reworkReason;
	}
	public void setReworkReason(String reworkReason) {
		this.reworkReason = reworkReason;
	}
	public String getRescheduleDate() {
		return rescheduleDate;
	}
	public void setRescheduleDate(String rescheduleDate) {
		this.rescheduleDate = rescheduleDate;
	}
	public String getTaskCreated() {
		return taskCreated;
	}
	public void setTaskCreated(String taskCreated) {
		this.taskCreated = taskCreated;
	}
	public String getDedupeStatus() {
		return dedupeStatus;
	}
	public void setDedupeStatus(String dedupeStatus) {
		this.dedupeStatus = dedupeStatus;
	}
    
}
    
	
