package com.fl.springjsp.sessionvariables;

import org.springframework.stereotype.Component;

import com.fl.springjsp.response.TcAgentResponseDTO;

@Component
public class SessionVariables {
    
    private String username;
    private TcAgentResponseDTO tcResponse;

    public TcAgentResponseDTO getTcResponse() {
		return tcResponse;
	}

	public void setTcResponse(TcAgentResponseDTO tcResponse) {
		this.tcResponse = tcResponse;
	}

	private static SessionVariables instance;

    private SessionVariables() {
        super();
    }

    public static synchronized SessionVariables getInstance() {
        if (instance == null) {
            instance = new SessionVariables();
        }
        return instance;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}


