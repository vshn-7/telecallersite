package com.fl.springjsp.response;

import java.util.ArrayList;

public class ReworkResponseDTO extends BaseResponseDTO{

    public ArrayList<ReworkLeadDetails> leadDetails;
    
	public ReworkResponseDTO() {
		super();
	}
	
	public ArrayList<ReworkLeadDetails> getLeadDetails() {
		return leadDetails;
	}
	public void setLeadDetails(ArrayList<ReworkLeadDetails> leadDetails) {
		this.leadDetails = leadDetails;
	}

}
