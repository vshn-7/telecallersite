package com.fl.springjsp.response;

public class TcAgentResponseDTO extends BaseResponseDTO{
	
	public String leadCount;
	public String googleCount;
	public String tcCount;
	public String promotionalOfferCount;
	public String monthleadCount;
	public String monthgoogleCount;
	
	public TcAgentResponseDTO() {
		super();
	}
	public String monthtcCount;
	public String monthpromotionalOfferCount;
	public String reworkcount;
	public String getLeadCount() {
		return leadCount;
	}
	public void setLeadCount(String leadCount) {
		this.leadCount = leadCount;
	}
	public String getGoogleCount() {
		return googleCount;
	}
	public void setGoogleCount(String googleCount) {
		this.googleCount = googleCount;
	}
	public String getTcCount() {
		return tcCount;
	}
	public void setTcCount(String tcCount) {
		this.tcCount = tcCount;
	}
	public String getPromotionalOfferCount() {
		return promotionalOfferCount;
	}
	public void setPromotionalOfferCount(String promotionalOfferCount) {
		this.promotionalOfferCount = promotionalOfferCount;
	}
	public String getMonthleadCount() {
		return monthleadCount;
	}
	public void setMonthleadCount(String monthleadCount) {
		this.monthleadCount = monthleadCount;
	}
	public String getMonthgoogleCount() {
		return monthgoogleCount;
	}
	public void setMonthgoogleCount(String monthgoogleCount) {
		this.monthgoogleCount = monthgoogleCount;
	}
	public String getMonthtcCount() {
		return monthtcCount;
	}
	public void setMonthtcCount(String monthtcCount) {
		this.monthtcCount = monthtcCount;
	}
	public String getMonthpromotionalOfferCount() {
		return monthpromotionalOfferCount;
	}
	public void setMonthpromotionalOfferCount(String monthpromotionalOfferCount) {
		this.monthpromotionalOfferCount = monthpromotionalOfferCount;
	}
	public String getReworkcount() {
		return reworkcount;
	}
	public void setReworkcount(String reworkcount) {
		this.reworkcount = reworkcount;
	}

	
	
}
