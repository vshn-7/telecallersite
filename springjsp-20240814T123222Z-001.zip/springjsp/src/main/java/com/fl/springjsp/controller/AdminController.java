package com.fl.springjsp.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.fl.springjsp.response.LeadResponseDTO;
import com.fl.springjsp.response.ReworkLeadDetails;
import com.fl.springjsp.response.ReworkResponseDTO;
import com.fl.springjsp.response.UnallocatedResponseDTO;
import com.fl.springjsp.response.TcAgentListResponseDTO;
import com.fl.springjsp.response.BaseResponseDTO;
import com.fl.springjsp.service.AdminService;
import com.fl.springjsp.sessionvariables.SessionVariables;

import jakarta.servlet.http.HttpServletRequest;
@Controller

public class AdminController {
	
	@Autowired
	public AdminService adminService;
	public static SessionVariables sessionInstance = SessionVariables.getInstance();
	
	@RequestMapping("/reallocateLeads")
	public String reallocateLeads(@RequestParam("leadId") String leadId,
            @RequestParam("custId") String custId,
            @RequestParam("name") String name,@RequestParam("tcAgent") String tcAgent,Model model) {
		TcAgentListResponseDTO response =   adminService.getTcAgentList();
		
		model.addAttribute("leadId", leadId);
        model.addAttribute("custId", custId);
        model.addAttribute("name", name);
        model.addAttribute("tcAgent", tcAgent);
		model.addAttribute("agentList",response.getTcAgentList());
		return "reallocateLeads";
	}
	
	@RequestMapping("/allocatedLeads")
	public String allocatedLeadsPage(Model model) {
		
		ReworkResponseDTO allocatedLeadDetails = adminService.getAllocatedLeads();
		if(allocatedLeadDetails.getStatusCode().equals("1")) {
			model.addAttribute("leadDetails",allocatedLeadDetails.getLeadDetails());
		}
		return "allocatedLeads";
	}
	
	@RequestMapping("/dashboard")
    public String dashboard(Model model) {	
       return "adminDashboard";
    }
	
	
	@RequestMapping("/rework")
	public String rework(Model model) {
	   BaseResponseDTO response =   adminService.leadDetails();

       model.addAttribute("response",response);
       
	   return "rework";
	}
	
	@RequestMapping("/unallocatedLeads")
    public String showUnallocatedLeads(Model model) {
        UnallocatedResponseDTO response = adminService.callUnallocatedLeadsApi();
        if(response!=null && response.getStatusCode()!="0")
        {
            model.addAttribute("response", response);
            return "unallocatedLeads";
        }
        model.addAttribute("errorMessage","Failed to fetch unallocated leads");
        return "error";
    }
	
	@RequestMapping("/overallLeads")
    public String showOverallLeads(Model model) {
        UnallocatedResponseDTO response=adminService.callOverallAllocatedLeadsApi();
        if(response!=null && response.getStatusCode()!="0")
        {
            model.addAttribute("response", response);
            return "overAllLeads";
        }
        
        model.addAttribute("errorMessage","Failed to fetch leads or no leads available.");
        return "error";
    }
	
	@PostMapping("/leadReallocate")
    public String leadReallocate(@RequestParam("leadId") String leadId,
            @RequestParam("custId") String custId, @RequestParam("custName") String custName,
            @RequestParam("custTcAgent") String custTcAgent, @RequestParam("newTcAgent") String newTcAgent,
            Model model) {
        BaseResponseDTO response = adminService.leadReallocate(leadId);
        if(response.getStatusCode().equals("1")) {
        	return "adminDashboard";
        }
        
       
       return "reallocateLeads";  
	}
	
	@RequestMapping("/reschedule")
    public String Reshedule(Model model) {
        
		ReworkResponseDTO response = adminService.leadDetails();
           
           
           if(response!=null && response.getStatusCode()!="0")
           {
               model.addAttribute("response",response);
               
        return "reshcedule";
           }
        
         model.addAttribute("onerror","Cannot find the leads for reshedule");
           return "error";
    }
	
	
}
