package com.fl.springjsp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.fl.springjsp.controller.MainController;
import com.fl.springjsp.request.BaseRequestDTO;
import com.fl.springjsp.request.LeadReallocateRequestDTO;
import com.fl.springjsp.request.LeadRequestDTO;
import com.fl.springjsp.response.BaseResponseDTO;
import com.fl.springjsp.response.LeadResponseDTO;
import com.fl.springjsp.response.ReworkResponseDTO;
import com.fl.springjsp.response.TcAgentListResponseDTO;
import com.fl.springjsp.response.UnallocatedResponseDTO;
import com.fl.springjsp.sessionvariables.SessionVariables;
import com.fl.springjsp.sessionvariables.Utils;


@Service
public class AdminService {
    public static RestTemplate restTemplate = new RestTemplate();
    public static LeadRequestDTO request = new LeadRequestDTO(Utils.appName,Utils.version);
    public static SessionVariables sessionInstance = SessionVariables.getInstance();
    
	public String reallocateLeads() {
		return "reallocateLeads";
	}
	

	public ReworkResponseDTO leadDetails() {
		
        request.setType("REWORK");
        request.setAgentCode(sessionInstance.getUsername());
        
        
        System.out.println(sessionInstance.getUsername());
        
        String url=Utils.url+"getTCAdminDashboardDetails";
        ReworkResponseDTO response  = restTemplate.postForObject(url, request, ReworkResponseDTO.class);
        return response;

    }
	
	public UnallocatedResponseDTO callUnallocatedLeadsApi()
    {
       
        request.setType("UNALLOCATED");

        request.setAgentCode(sessionInstance.getUsername());
        String url=Utils.url+"getTCAdminDashboardDetails";
        UnallocatedResponseDTO response=new UnallocatedResponseDTO();
        response= restTemplate.postForObject(url, request, UnallocatedResponseDTO.class);
        return response;
    }
	
	public UnallocatedResponseDTO callOverallAllocatedLeadsApi()
    {
		request.setAgentCode(sessionInstance.getUsername());
        request.setType("OVERALL");
       
        
        String url=Utils.url+"getTCAdminDashboardDetails";
        UnallocatedResponseDTO response=restTemplate.postForObject(url, request,UnallocatedResponseDTO.class);
        return response;
    }
	
	public TcAgentListResponseDTO getTcAgentList() {
		BaseRequestDTO request = new BaseRequestDTO();
		request.setAgentCode(sessionInstance.getUsername());
        request.setAppName(Utils.appName);
        request.setVersion(Utils.version);
        

        String url=Utils.url+"getWebMeta";
        TcAgentListResponseDTO response=restTemplate.postForObject(url, request,TcAgentListResponseDTO.class);
        return response;
	}


	public ReworkResponseDTO getAllocatedLeads() {
		ReworkResponseDTO allocatedLeadDetails = null;
		String apiUrl = Utils.url+"getTCAdminDashboardDetails";
		request.setAgentCode(sessionInstance.getUsername());
		request.setType("ALLOCATED");
		
		try {
			HttpEntity<LeadRequestDTO> requestEntity = new HttpEntity<>(request);
			
			RestTemplate restTemplate = new RestTemplate();
			ResponseEntity<ReworkResponseDTO> response = restTemplate.exchange(
			        apiUrl,
			        HttpMethod.POST,
			        requestEntity,
			        ReworkResponseDTO.class
			);
			if(response!=null) {
				allocatedLeadDetails = response.getBody();
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		return allocatedLeadDetails;
		
	}
	
	public ReworkResponseDTO reshedule() {
			ReworkResponseDTO response =new ReworkResponseDTO();
	        String url = Utils.url+"getTCAdminDashboardDetails";
			request.setAgentCode(sessionInstance.getUsername());
			request.setType("RESHEDULE");
	        response =restTemplate.postForObject(url, request, ReworkResponseDTO.class);
	        return response ;
        
    }
	
	public BaseResponseDTO leadReallocate(String leadId) {
		LeadReallocateRequestDTO request = new LeadReallocateRequestDTO();
		request.setTcAgentCode(sessionInstance.getUsername());
        request.setAppName(Utils.appName);
        request.setVersion(Utils.version);
        request.setLeadId(leadId);

        String url=Utils.url+"UpdateTCAgent";
        BaseResponseDTO response=restTemplate.postForObject(url, request,BaseResponseDTO.class);
        return response;
		
	}



}
