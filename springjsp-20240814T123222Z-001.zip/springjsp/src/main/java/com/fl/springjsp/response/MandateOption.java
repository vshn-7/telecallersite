package com.fl.springjsp.response;

public class MandateOption{
    public String option;
    public String displayString;
}
