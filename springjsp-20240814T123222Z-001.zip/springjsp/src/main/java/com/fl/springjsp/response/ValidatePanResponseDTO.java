package com.fl.springjsp.response;

public class ValidatePanResponseDTO extends BaseResponseDTO{
	private String fname;
	private String lname;
	private String fullName;
	private boolean enabled;
	private String disabledMessage;
	
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public boolean isEnabled() {
		return enabled;
	}
	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
	public String getDisabledMessage() {
		return disabledMessage;
	}
	public void setDisabledMessage(String disabledMessage) {
		this.disabledMessage = disabledMessage;
	}
	
	@Override
	public String toString() {
		return "ValidatePanResponseDTO [fname=" + fname + ", lname=" + lname + ", fullName=" + fullName + ", enabled="
				+ enabled + ", disabledMessage=" + disabledMessage + ", toString()=" + super.toString() + "]";
	}

}
