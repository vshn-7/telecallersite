package com.fl.springjsp.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fl.springjsp.request.BaseRequestDTO;
import com.fl.springjsp.request.CommonLeadRequestDTO;
import com.fl.springjsp.request.GetOTPRequestDTO;
import com.fl.springjsp.request.LeadRequestDTO;
import com.fl.springjsp.request.LeadSubmitRequestDTO;
import com.fl.springjsp.request.ValidatePanRequestDTO;
import com.fl.springjsp.request.VerifyOTPRequestDTO;
import com.fl.springjsp.response.BaseResponseDTO;
import com.fl.springjsp.response.CommonLeadResponseDTO;
import com.fl.springjsp.response.GetOTPResponseDTO;
import com.fl.springjsp.response.LeadResponseDTO;
import com.fl.springjsp.response.LeadSubmitResponseDTO;
import com.fl.springjsp.response.MetaResponseDTO;
import com.fl.springjsp.response.ValidatePanResponseDTO;
import com.fl.springjsp.sessionvariables.SessionVariables;
import com.fl.springjsp.sessionvariables.Utils;

import jakarta.servlet.http.HttpSession;
import org.springframework.http.client.SimpleClientHttpRequestFactory;


@Service
public class TcService {
	public static SessionVariables sessionInstance = SessionVariables.getInstance();
	public static RestTemplate restTemplate = new RestTemplate();

	public static BaseRequestDTO baseRequest = new BaseRequestDTO(Utils.appName,Utils.version);
	
	public MetaResponseDTO addLead() {
		String url = Utils.url+"getMetaData";
		baseRequest.setAgentCode(sessionInstance.getUsername());
		System.out.println(sessionInstance.getUsername());
        MetaResponseDTO response = restTemplate.postForObject(url, baseRequest, MetaResponseDTO.class);
        
        return response;
	}
	
    public LeadResponseDTO callMyLeadApi() {

        
        String url = Utils.url+"getTCAgentLeadList"; 
		baseRequest.setAgentCode(sessionInstance.getUsername());
	
		LeadResponseDTO response = restTemplate.postForObject(url, baseRequest, LeadResponseDTO.class);

        return response;
    }


	private GetOTPRequestDTO getOTPRequestDTO = new GetOTPRequestDTO();
	
	private GetOTPResponseDTO getOTPResponseDTO = new GetOTPResponseDTO();
	
	private VerifyOTPRequestDTO verifyOTPRequestDTO = new VerifyOTPRequestDTO();
	
	
	public MetaResponseDTO dropdowns() {

		String url = Utils.url+"getMetaData";
		BaseRequestDTO baseRequestDTO = new BaseRequestDTO();
		baseRequestDTO.setAppName(Utils.appName);
		baseRequestDTO.setVersion(Utils.version);
		baseRequestDTO.setAgentCode(sessionInstance.getUsername());
		
		MetaResponseDTO metaDataResponse = null;
		try{
			metaDataResponse = restTemplate.postForObject(url, baseRequestDTO, MetaResponseDTO.class);
		}catch(Exception e) {
			System.out.println("Error while fetching Meta Data " + e.getMessage());
		}
		return metaDataResponse;
	}
	
	public String generateRandomOTP(String name, String phoneNo, String businessName, String businessType) {
		
		String getOTPUrl = Utils.url+ "getOTP" ; 
		getOTPRequestDTO.setName(name);
		getOTPRequestDTO.setPhoneNo(phoneNo);
		getOTPRequestDTO.setBusinessName(businessName);
		getOTPRequestDTO.setLeadSource(businessType);
		getOTPRequestDTO.setAppName(Utils.appName);
		getOTPRequestDTO.setVersion(Utils.version);
		getOTPRequestDTO.setAgentId("");
		getOTPRequestDTO.setLeadId("");
		
		System.out.println("url--------------->"+getOTPUrl);
		
		try{
			System.out.println("getOTPRequestDTO request---------->" + getOTPRequestDTO.toString());
			 ((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory()).setConnectTimeout(1000 * 600);
		     ((SimpleClientHttpRequestFactory) restTemplate.getRequestFactory()).setReadTimeout(1000 * 600);
			getOTPResponseDTO = restTemplate.postForObject(getOTPUrl, getOTPRequestDTO, GetOTPResponseDTO.class);
			System.out.println("getOTPResponseDTO " + getOTPResponseDTO.toString());
			return getOTPResponseDTO.getOtp();
			
		}catch(Exception e) {
			System.out.println("Error in getOTPResponseDTO ---------------> "+ e.getMessage());
		}
		return null;
		
    }

	public boolean verifyOTP(String userOtp, HttpSession session) {	
	
		return getOTPResponseDTO.getOtp().equals(userOtp);
	}

	public Map<String, String> verifyPAN(String pan, HttpSession session) {
		
		String validatePanUrl = Utils.url + "validatePanNumber";
		ValidatePanRequestDTO validatePanRequestDTO = new ValidatePanRequestDTO();
		validatePanRequestDTO.setAppName(getOTPRequestDTO.getAppName());
		validatePanRequestDTO.setLeadId(getOTPResponseDTO.getLeadId());
		validatePanRequestDTO.setPan(pan);
		validatePanRequestDTO.setVersion(getOTPRequestDTO.getVersion());
		
		
		System.out.println("validatePanRequestDTO---------------->"+ validatePanRequestDTO.toString());
		ValidatePanResponseDTO validatePanResponseDTO = null;
		Map<String, String> panDetails = new HashMap<>();
		try{
			validatePanResponseDTO = restTemplate.postForObject(validatePanUrl, validatePanRequestDTO, ValidatePanResponseDTO.class);
			System.out.println("verifyPAN response ------------>" + validatePanResponseDTO.toString());
			if(validatePanResponseDTO.getStatusCode().equals(("1"))) {
				panDetails.put("firstName", validatePanResponseDTO.getFname());
		        panDetails.put("lastName", validatePanResponseDTO.getLname());
		        panDetails.put("fullName", validatePanResponseDTO.getFullName());
		        return panDetails;
			}
		}catch(Exception e) {
			System.out.println("Error while Verifying PAN :" + e.getMessage());
		}
		
		return null;
	}

	public void leadSubmit(String businessPincode, String businessType, String loanPurpose, String dailyUpi,
			String dailyCash, String workingDays, String maritalStatus, String businessAddress, String custId) {
		
		String leadSubmitUrl = Utils.url + "getProvisionalOffer";
		LeadSubmitRequestDTO leadSubmitRequestDTO = new LeadSubmitRequestDTO();
		leadSubmitRequestDTO.setLeadId(getOTPResponseDTO.getLeadId());
		leadSubmitRequestDTO.setBusinessPincode(businessPincode);
		leadSubmitRequestDTO.setBusinessType(businessType);
		leadSubmitRequestDTO.setLoanPurpose(loanPurpose);
		leadSubmitRequestDTO.setDailyUpi(dailyUpi);
		leadSubmitRequestDTO.setDailyCash(dailyCash);
		leadSubmitRequestDTO.setWorkingDays(workingDays);
		leadSubmitRequestDTO.setMaritalStatus(maritalStatus);
		leadSubmitRequestDTO.setBusinessAddress(businessAddress);
		leadSubmitRequestDTO.setAppName(getOTPRequestDTO.getAppName());
		leadSubmitRequestDTO.setVersion(getOTPRequestDTO.getVersion());
		leadSubmitRequestDTO.setCustId(custId);
		leadSubmitRequestDTO.setCustomerId(custId);
		
		BaseResponseDTO baseResponseDTO = null;
		try{
			System.out.println("leadSubmitRequestDTO--------------> "+ leadSubmitRequestDTO.toString());
			baseResponseDTO = restTemplate.postForObject(leadSubmitUrl, leadSubmitRequestDTO, BaseResponseDTO.class);
			System.out.println("leadSubmitResponseDTO--------------> "+ baseResponseDTO.toString());
		}catch(Exception e) {
			System.out.println("Error while Lead Submit" + e.getMessage());
		}
		return;
	}
	
	public String dedupeLead() {
		
		String leadSubmitUrl = Utils.url + "dedupeLead";
		CommonLeadRequestDTO commonLeadRequest = new CommonLeadRequestDTO();
		commonLeadRequest.setLeadId(getOTPResponseDTO.getLeadId());
		commonLeadRequest.setLeadSource(getOTPRequestDTO.getLeadSource());
		commonLeadRequest.setAgentCode(sessionInstance.getUsername());
		commonLeadRequest.setAppName(Utils.appName);
		commonLeadRequest.setVersion(Utils.version);
		
		CommonLeadResponseDTO commonLeadResponse = null;
		try{
			System.out.println("dedupeLead request--------------> "+ commonLeadRequest.toString());
			commonLeadResponse = restTemplate.postForObject(leadSubmitUrl, commonLeadRequest, CommonLeadResponseDTO.class);
			System.out.println("dedupeLead response--------------> "+ commonLeadResponse.toString());
			return commonLeadResponse.getCustId();
		}catch(Exception e) {
			System.out.println("Error while dedupeLead" + e.getMessage());
		}
		return null;
		
	}

}